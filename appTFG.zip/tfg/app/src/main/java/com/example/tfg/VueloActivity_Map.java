package com.example.tfg;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.PointF;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.Image;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.common.ViewObject;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapGesture;
import com.here.android.mpa.mapping.MapMarker;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class VueloActivity_Map extends AppCompatActivity implements LocationListener {

    private List mapMakers;
    private List puntos;
    private List<Double> longitudes;
    private List<Double> latitudes;

    private Map map;
    private MapFragment mapFragment;
    private GeoCoordinate droneCord;
    private LocationManager locationManager;

    boolean vuelta;
    double altura;
    String ip;
    String port;

    double longitud;
    double latitud;




    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vuelo_map);

        Bundle ajustes = getIntent().getExtras();

        ini();


        ip  = ajustes.getString("ip");
        port = ajustes.getString("port");
        altura = ajustes.getDouble("altura");
        vuelta = ajustes.getBoolean("volverOrig");

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e("errorUbicacion", "no se ha podido obtener la ubicacion");
            return;
        }
        Location location = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);

        onLocationChanged(location);

        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);

        mapFragment.init(new OnEngineInitListener() {

            @Override
            public void onEngineInitializationCompleted(OnEngineInitListener.Error error) {
                if (error == OnEngineInitListener.Error.NONE) {

                    mapFragment.getMapGesture().addOnGestureListener(new MyOnGestureListener());

                    map = mapFragment.getMap();

                    setDroneCord();
                    map.setCenter(droneCord, Map.Animation.NONE);
                    map.setZoomLevel(map.getMaxZoomLevel(), Map.Animation.NONE);

                    setDroneMarker();


                }

                else
                    Log.e("VueloActivity_Map","error al iniciar los componentes del mapa");

            }
        });
    }

    @Override
    public void onLocationChanged(Location location) {
        longitud = location.getLongitude();
        latitud = location.getLatitude();
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {}

    @Override
    public void onProviderEnabled(String s) {}

    @Override
    public void onProviderDisabled(String s) {}


    private void ini(){
        mapMakers = new ArrayList();
        puntos = new ArrayList();
        longitudes = new ArrayList();
        latitudes = new ArrayList();
    }

    private void setDroneCord(){
        droneCord = new GeoCoordinate(latitud, longitud);
    }

    private void setDroneMarker(){

        Image marker_img = new Image();
        try {
            marker_img.setImageAsset("drone.png");
        } catch (IOException e) {
            e.printStackTrace();
        }

        MapMarker m = new MapMarker().setCoordinate(droneCord);
        m.setIcon(marker_img);
        mapMakers.add(m);
        map.addMapObject(m);

    }

    private void actualizarMarker() {

        if (puntos.size() <= 10) { // 10 puntos maximo

            PointF point = (PointF) puntos.get(puntos.size() - 1);
            GeoCoordinate cord = map.pixelToGeo(point);

            latitudes.add(cord.getLatitude());
            longitudes.add(cord.getLongitude());

            Image marker_img = new Image();

            try {
                String concat = puntos.size() + ".png";
                marker_img.setImageAsset(concat);
            } catch (IOException e) {
                e.printStackTrace();
            }


            MapMarker m = new MapMarker().setCoordinate(cord);
            m.setIcon(marker_img);
            mapMakers.add(m);
            map.addMapObject(m);
        }
    }

    public void btnReset(View view){
        map.removeMapObjects(mapMakers); //borramos marcadores del mapa
        ini();
        setDroneMarker();
    }

    public void btnIniciar(View view){
        Intent intent = new Intent(this, VueloActivity_Msg.class);

        double lats [] = new double [latitudes.size()];
        double lngs [] = new double [longitudes.size()];

        for(int i= 0; i<latitudes.size(); i++) {
            lats[i] = latitudes.get(i);
            lngs[i]= longitudes.get(i);
        }

        intent.putExtra("volverOrig", vuelta);
        intent.putExtra("altura", altura);
        intent.putExtra("ip", ip);
        intent.putExtra("port", port);
        intent.putExtra("lng",lngs);
        intent.putExtra("lat",lats);

        startActivity(intent);
    }

    private class MyOnGestureListener implements MapGesture.OnGestureListener {

        @Override
        public boolean onTapEvent(PointF pointF) {
            puntos.add(pointF);
            actualizarMarker();
            return true;
        }

        @Override
        public void onPanStart() {}

        @Override
        public void onPanEnd() {}

        @Override
        public void onMultiFingerManipulationStart() {}

        @Override
        public void onMultiFingerManipulationEnd() {}

        @Override
        public boolean onMapObjectsSelected(List<ViewObject> list) {
            return false;
        }

        @Override
        public boolean onDoubleTapEvent(PointF pointF) {
            return false;
        }

        @Override
        public void onPinchLocked() {}

        @Override
        public boolean onPinchZoomEvent(float v, PointF pointF) {
            return false;
        }

        @Override
        public void onRotateLocked() {}

        @Override
        public boolean onRotateEvent(float v) {
            return false;
        }

        @Override
        public boolean onTiltEvent(float v) {
            return false;
        }

        @Override
        public boolean onLongPressEvent(PointF pointF) {
            return false;
        }

        @Override
        public void onLongPressRelease() {}

        @Override
        public boolean onTwoFingerTapEvent(PointF pointF) {
            return false;
        }
    }

}