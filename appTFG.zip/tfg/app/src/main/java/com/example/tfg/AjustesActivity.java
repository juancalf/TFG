package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

public class AjustesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);
    }
      
    public void btnGuardar(View view){
        EditText ip = (EditText) findViewById(R.id.editText);
        EditText port = (EditText) findViewById(R.id.editText2);
        EditText altura = (EditText) findViewById(R.id.editText3);
        Switch ret = (Switch) findViewById(R.id.switch1);

        Intent intent = new Intent(this, MainActivity.class);

        intent.putExtra("ip", ip.getText().toString());
        intent.putExtra("port", port.getText().toString());
        intent.putExtra("altura", Double.parseDouble(altura.getText().toString()));
        intent.putExtra("volverOrig", ret.isChecked());

        startActivity(intent);
    }



}
