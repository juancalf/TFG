package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {
    private String ip;
    private String port;
    private double altura;
    private boolean volverOrig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //oculta la barra de titulo para la vista principal
        Bundle ajustes = getIntent().getExtras();
        if (ajustes == null) {
            ip = "192.168.1.36";
            port = "12345";
            altura = 3;
            volverOrig = false;
        }
        else{
            ip = ajustes.getString("ip");
            port = ajustes.getString("port");
            altura = ajustes.getDouble("altura");
            volverOrig = ajustes.getBoolean("volverOrig");
        }
    }

    public void btnInicioVuelo(View view){
        Intent intent = new Intent(this, VueloActivity_Map.class);
        intent.putExtra("ip", ip);
        intent.putExtra("port", port);
        intent.putExtra("altura", altura);
        intent.putExtra("volverOrig", volverOrig);
        startActivity(intent);
    }

    public void btnAjustes(View view){
        Intent intent = new Intent(this, AjustesActivity.class);
        startActivity(intent);
    }

    public void btnInfo(View view){
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);
    }

}
